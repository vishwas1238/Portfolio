import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {

    public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html><body>");
        out.println("<h2>Product Details</h2>");
        out.println("<table border='1'><tr><th>ProdCode</th><th>PName</th><th>Price</th></tr>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/testdb","root","@admin123");

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Product");

            while(rs.next()) {
                out.println("<tr><td>"+rs.getInt(1)+"</td>"
                +"<td>"+rs.getString(2)+"</td>"
                +"<td>"+rs.getDouble(3)+"</td></tr>");
            }

            con.close();

        } catch(Exception e) {
            out.println("<h3>Error: "+e.getMessage()+"</h3>");
        }

        out.println("</table></body></html>");
    }
}